##additional lines for the parallel execution
args <- commandArgs(trailingOnly = TRUE)
seed = as.numeric(args[1])
cat(paste("Seed=",seed,"\n")) #print a random seed

library(here)
scencsvpath <- here("scen_new.csv")
library(brms)
library(data.table)
library(dplyr)
#library(doMC)

timetransform = log # g(t) or h(t) in paper notations
NULLCASE=FALSE
SCENNO = 11 #change scenario if needed
cohortsize = 30 # 3 subjects in each arm / change cohortsize if needed
ScenNum = SCENNO

determineordinal<-function(value, thresvector){
  return(length(which(thresvector < value))+1)
}

simulatecohort<-function(vec_num_subj, beta_vec,gamma_vec, thresvec_beta,thresvec_gamma, sd, raneffsd,cohorttime,timetransform=log){
  ### vec_num_subj, vector of subjects for the S and E arms ##further, vec_num_subj=c(1,1) * cohortsize
  ### beta_vec (one value actually), coef for the E's efficacy: Y = beta_0 * log(t) + u_i + eps_y
  ### gamma_vec (one value actually), coefficient for the S's efficacy: W = gamma_0 * log(t) + u_i + eps_w
  ### thresvec_beta, thresholds for the E's efficacy's ordinal outcome
  ### thresvec_gamma, thresholds for the S's efficacy's ordinal outcome
  ### sd, random error in the ordinal model, we assume all the same for E,ScenNum
  ### raneffsd, sd of random effect in the E's ordinal model
  
  numS = vec_num_subj[1] #number of subjects for the standard arm
  numE = vec_num_subj[2] #number of subjects for the experimental arm
  
  raneffS = rnorm(numS,0,raneffsd) #random effect of subjects in the standard arm
  raneffE = rnorm(numE,0,raneffsd) #random effect of subjects in the experimental arm
  
  subjectIDE = cohorttime * 10000 + seq(1,length(raneffE)) #identificators for subjects
  subjectIDS = cohorttime * 100000 + seq(1,length(raneffS))
  
  #xxE - simulates efficacy data in the experimental setting   
  xxE= lapply(1:length(raneffE),function(i){
    raneff = raneffE[i] #random effect from above is assigned to the current object
    d = rep(0,T) #left for dimensions correspondence, not used afterwards
    d2 = rep(0,T)
    t = 1:T
    m = as.matrix(cbind(sapply(t,timetransform), d, d2 )) %*% (as.matrix(beta_vec)) #10*3 x 3*1 --> dim = (10,1)
    #m - efficacy model, matrices multiplication; each row represents a time point for a specific subject
    latent = sapply(1:nrow(m),function(i){rnorm(1,m[i,1],sd = sd)}) + raneff #Y^(~i)
    observed = sapply(latent,function(i){determineordinal(i,thresvec_beta)})
    #the res of "observed" - is each entry is the ordinal category corresponding to each time point's latent efficacy score
    realt = cohorttime + t - 1
    wgt = rep(1,T) #weight
    subjid = subjectIDE[i]
    ident_num = 1
    o = data.frame(subjectID = rep(subjid,T),ident_num = ident_num, realtime = realt, relativetime = t, raneff = rep(raneff,T), effoutcome = observed, latent=latent,cohorttime = rep(cohorttime,T),w=wgt)
    return(o) 
    #return(o) involves individual df's per each subject with T rows each
  })%>%Reduce(rbind,.) # united all the df's into one df
  
  #check and ensuring all possible ordinal outcomes are presented in xxE (E setting) for efficacy
  if (length(unique(xxE$effoutcome))<numordinalE){
    toadd = setdiff(seq(1,numordinalE),unique(xxE$effoutcome)) #identifying missing categories, store them in "toadd"
    for(i in 1:length(toadd)){
      tempE = xxE[1:T,] #copies the first T rows of xxE
      tempE$relativetime=10
      tempE$w = 0.0001 #indicate a very low weight for them (since they're artificially added)
      tempE$effoutcome = toadd[i] #assigns one of the missing categories to the efficacy outcome
      xxE = rbind(xxE,tempE) #appends these rows to the original dataset
    }
  }
  
  #same for the standard arm
  xxS= lapply(1:length(raneffS),function(i){
    raneff = raneffS[i]
    d = rep(0,T)
    d2 = rep(0,T)
    t = 1:T
    m = as.matrix(cbind(sapply(t,timetransform)) ) %*% (as.matrix(gamma_vec))
    latent = sapply(1:nrow(m),function(i){rnorm(1,m[i,1],sd = sd)}) + raneff
    observed = sapply(latent,function(i){determineordinal(i,thresvec_gamma)})
    realt = cohorttime + t - 1
    subjid = subjectIDS[i]
    ident_num = 0
    wgt = rep(1,T)
    o = data.frame(subjectID = rep(subjid,T),ident_num=ident_num,realtime = realt, relativetime = t, raneff = rep(raneff,T), effoutcome = observed, latent=latent,cohorttime = rep(cohorttime,T),w=wgt)
    return(o)
  })%>%Reduce(rbind,.)
  
  if (length(unique(xxS$effoutcome))<numordinalE){
    toadd = setdiff(seq(1,numordinalE),unique(xxS$effoutcome))
    for(i in 1:length(toadd)){
      tempE = xxS[1:T,]
      tempE$w = 0.0001
      tempE$effoutcome = toadd[i]
      xxS = rbind(xxS,tempE)
    }
  }
  
  return(rbind(xxE,xxS))
}


#efficacy probability in the Experimental setting 
#пE used to compute a summary measure
geteffprobE<-function(time,thresholdvec,btime,raneffsd,timetransform){
  
  sdx=1+raneffsd
  m = btime * timetransform(time) #Yi (t) = beta_0 * log(t) + u_i + eps_y
  thres = c(-Inf,thresholdvec,Inf)
  o=sapply(2:length(thres),function(i){pnorm(thres[i],mean = m,sd = sdx) - pnorm(thres[i-1],mean = m,sd = sdx)})
  #calculates the probability that the efficacy score is between thres[i-1] and thres[i] through CDF
  return(o)
}

#same for the standard arm
geteffprobS<-function(time,thresholdvec,btime,raneffsd,timetransform){
  
  sdx=1+raneffsd
  m = btime * timetransform(time)
  thres = c(-Inf,thresholdvec,Inf)
  o=sapply(2:length(thres),function(i){pnorm(thres[i],mean = m,sd = sdx) - pnorm(thres[i-1],mean = m,sd = sdx)})
  return(o)
  
}

#computes the summary measure pS for the standard arm using generated "pos"
computepS<-function(pos,bE,wtime,timetransform=log){
  #pos is a table of posterior samples for S's efficacy, first 3 columns is the threshold, 4 column is the time coeffcient
  
  thres_est = pos[,1:3]
  btime_est = pos[,4]	
  raneffsd_est = pos[,5]
  
  pd=sapply(1:length(btime_est),function(i){
    probs = sapply(1:10,function(t)(sum(bE * geteffprobS(t,as.numeric(thres_est[i,]),btime_est[i],raneffsd_est[i],timetransform))))
    sum(wtime*probs)/sum(wtime)
  })
  return(pd)
}

#2.2 a summary measure, Efficacy in the Experimental arm (pd in the paper)
computepE<-function(pos,bE,wtime,timetransform=log){
  #pos is a table of posterior samples for E's efficacy, first 3 columns is the threshold, 4 column is the time coeffcient
  
  thres_est = pos[,1:3]
  btime_est = pos[,4]
  raneffsd_est = pos[,5]
  
  pd=sapply(1:length(btime_est),function(i){
    probs = sapply(1:10,function(t)(sum(bE * geteffprobE(t,as.numeric(thres_est[i,]),btime_est[i],raneffsd_est[i],timetransform))))
    sum(wtime*probs)/sum(wtime)
  })
  return(pd)
}

#compute same summary measures, but with the true (predefined) parameters	  
computepS_true<-function(thresvec_gamma,gamma_vec,raneffsd,bE,wtime,timetransform=log){
  thres_est = thresvec_gamma
  btime_est = gamma_vec	
  raneffsd_est = raneffsd
  
  pd=sapply(1:1,function(i){
    probs = sapply(1:10,function(t)(sum(bE * geteffprobS(t,as.numeric(thres_est),btime_est,raneffsd_est,timetransform))))
    sum(wtime*probs)/sum(wtime)
  })
  return(pd)
}


computepE_true<-function(thresvec_beta,beta_vec,raneffsd,bE,wtime,timetransform=log){
  thres_est = thresvec_beta
  btime_est = beta_vec[1]
  raneffsd_est = raneffsd
  
  pd=sapply(1:1,function(i){
    probs = sapply(1:10,function(t)(sum(bE * geteffprobE(t,as.numeric(thres_est),btime_est,raneffsd_est,timetransform))))
    sum(wtime*probs)/sum(wtime)
  })
  return(pd)
}


vec_num_subj=c(1,1) * cohortsize # 2 arms
wtime=c(rep(0,9),rep(1,1)) #weighting factor for time
bE = c(0,0,1,1) #weighting factor for ordinal probability

cohorttime = 1
T=10

sd = 1
raneffsd = 0.1
numordinalE = 4 #efficacy outcome is ordinal with 4 levels

######Calibration for S

timetransform <<- log

tempf<-function(x){
  gamma_vec = c(x)
  thresvec_gamma = c(2,3.5,4)
  computepS_true(thresvec_gamma,gamma_vec,raneffsd,bE,wtime)	- targetpdS
} #get a difference b/w model's prediction and target value

scencsv = read.csv(scencsvpath)

targetpdS = scencsv$ps[ScenNum] #####SCENNO number for target, as there are different pS
gamma_vec = uniroot(tempf,c(0.1,2))$root #to solve the equation within [0.1, 2] such that computepS_true matches the targetpdS value
thresvec_gamma = c(2,3.5,4)

oo = lapply(1:10,function(tt){
  wtime = rep(0,10)
  wtime[tt]=1
  
  sapply(1:4,function(ii){ 
    bEtemp = rep(0,4) ##4 -- 4 ordinal levels
    bEtemp[ii] = 1
    computepS_true(thresvec_gamma,gamma_vec,raneffsd,bEtemp,wtime)	
  })
})%>%do.call(rbind,.)

#oo
#10 rows (diff time points) and 4 cols(diff results of the function computepdS_true)


######Calibration for E 
scencsv = read.csv(scencsvpath)
PS = scencsv$ps[ScenNum]

eff_solve<-function(pds,PS){ 
  
  tempf<-function(x){
    gamma_vec = c(x)
    thresvec_gamma = c(2,3.5,4)
    computepS_true(thresvec_gamma,gamma_vec,raneffsd,bE,wtime)	-  PS
  }
  
  gamma_vec = uniroot(tempf,c(0.1,2))$root
  
  tempf2<-function(x){
    beta_vec = c(gamma_vec,x,0)
    thresvec_beta = c(2,3.5,4) + beta_vec[2]
    ll = computepE_true(thresvec_beta,beta_vec,raneffsd,bE,wtime) 
    ll - targetdiff
  }
  
  targetdiff =  pds[1]
  beta_vecdose = uniroot(tempf2,c(0.05,10),extendInt = "yes")$root
  beta_vec = c(gamma_vec,beta_vecdose,0)
  thresvec_beta = c(2,3.5,4) + beta_vec[2]
  pdtrue = computepE_true(thresvec_beta,beta_vec,raneffsd,bE,wtime)
  return(list(beta_vec=beta_vec,thresvec_beta=thresvec_beta,pdtrue=pdtrue))
}


pds = scencsv[SCENNO,1] #col with pE, the first row at first
eff_solu = eff_solve(pds,scencsv[SCENNO,2]) #scencsv[SCENNO,2] - pS value
beta_vec = eff_solu$beta_vec
thresvec_beta = eff_solu$thresvec_beta
pdtrue = eff_solu$pdtrue
print(pds) #the target value extracted from a file
print(eff_solu$pdtrue) #the simulated value resulted from the calibration process

if(NULLCASE){
  beta_vec = c(gamma_vec,0,0)  
  thresvec_beta = c(2,3.5,4) 
}


#fitting
aa= simulatecohort(vec_num_subj, beta_vec, gamma_vec, thresvec_beta,thresvec_gamma, sd, raneffsd,cohorttime)
#aa 

fitS <<- brm(formula = effoutcome|weights(w) ~ relativetime  + (1 | subjectID), data = aa[which(aa$ident_num == 0), ], 
             family = cumulative(link="probit",threshold = "flexible"),save_all_pars=TRUE,
             warmup = 1000,iter = 2000, chains = 1 )

fitE <<- brm(formula = effoutcome|weights(w) ~ relativetime +(1 | subjectID), data = aa[which(aa$ident_num == 1), ], 
             family = cumulative(link="probit",threshold = "flexible"), save_all_pars=TRUE,
             warmup = 1000,iter = 2000, chains = 1 )  

vec_num_subj=c(1,1) * cohortsize

#sim=1
#set.seed(sim)
set.seed(seed)
resultlist=list()

fulldat = simulatecohort(vec_num_subj, beta_vec,  gamma_vec, thresvec_beta,thresvec_gamma, sd, raneffsd,cohorttime)

for (tt in 1:3*T){ #loop iterates from 1 to 10
  cohorttime=tt
  if (tt == 1){
    fulldat = simulatecohort(vec_num_subj, beta_vec,  gamma_vec, thresvec_beta,thresvec_gamma, sd, raneffsd,cohorttime)
  }else{
    tempdat = simulatecohort(vec_num_subj, beta_vec,  gamma_vec, thresvec_beta,thresvec_gamma, sd, raneffsd,cohorttime)
    fulldat = rbind(fulldat,tempdat) #
  }
}

timetransform<<-log

fitmodel<-function(dat){
  aa=dat
  fitS <<- brm(formula = effoutcome|weights(w) ~ relativetime  + (1 | subjectID), data = aa[which(aa$ident_num == 0), ], 
               family = cumulative(link="probit",threshold = "flexible"),save_all_pars=TRUE,
               warmup = 1000,iter = 2000, chains = 1 )
  
  fitE <<- brm(formula = effoutcome|weights(w) ~ relativetime +(1 | subjectID), data = aa[which(aa$ident_num == 1), ], 
               family = cumulative(link="probit",threshold = "flexible"), save_all_pars=TRUE,
               warmup = 1000,iter = 2000, chains = 1 )  
  
  posE=posterior_samples(fitE)
  posS=posterior_samples(fitS)
  
  return(list(posE=posE,posS=posS,fitE=fitE,fitS=fitS))
}

resultsummary<-function(modelfit){
  if (class(modelfit) == 'try-error')return(999)
  
  posE= modelfit$posE
  posS= modelfit$posS
  
  pdEls = computepE(posE,bE,wtime)
  pdSls = computepS(posS,bE,wtime)
  pdE = mean(pdEls)
  pdS = mean(pdSls)
  
  pdS_true = computepS_true(thresvec_gamma,gamma_vec,raneffsd,bE,wtime)
  pdE_true = computepE_true(thresvec_beta,beta_vec,raneffsd,bE,wtime)
  
  return(list(pdEls=pdEls,  #one E's efficacy summary value
              pdSls = pdSls,  #posterior sample of S's efficacy summary value
              pdE=pdE,   ## one of E's efficacy summary value
              pdS=pdS   ## posterior mean of S's efficacy summary value
  ))    
  
}

subdat = fulldat[which(fulldat$realtime <= T),]
subdat$relativetime = timetransform(subdat$relativetime)  
modelfit = try(fitmodel(subdat))
res = resultsummary(modelfit)
resultlist[[1]] = res  


subdat = fulldat[which(fulldat$realtime <= 1.5*T),]
subdat$relativetime = timetransform(subdat$relativetime)
modelfit = try(fitmodel(subdat))
res = resultsummary(modelfit)
resultlist[[2]] = res


subdat = fulldat[which(fulldat$realtime <= 2*T),]
subdat$relativetime = timetransform(subdat$relativetime)
modelfit = try(fitmodel(subdat))
res = resultsummary(modelfit)
resultlist[[3]] = res


subdat = fulldat[which(fulldat$realtime <= 2.5*T),]
subdat$relativetime = timetransform(subdat$relativetime)
modelfit = try(fitmodel(subdat))
res = resultsummary(modelfit)
resultlist[[4]] = res


subdat = fulldat[which(fulldat$realtime <= 3*T),]
subdat$relativetime = timetransform(subdat$relativetime)
modelfit = try(fitmodel(subdat))
res = resultsummary(modelfit)
resultlist[[5]] = res

output_filename <- paste0(ScenNum, "_", seed, ".rds")
saveRDS(resultlist, here(output_filename))

output_filename <- paste0(ScenNum, "_", seed, "_dat.rds")
saveRDS(fulldat, here(output_filename))
